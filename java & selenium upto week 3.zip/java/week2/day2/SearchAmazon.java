package week2.day2;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class SearchAmazon {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		
		driver.get("https://www.amazon.in/");
		
		WebElement findListOfValues = driver.findElementByXPath("//select[contains(@class,'nav-search-dropdown')]");
		
		String listValues = findListOfValues.getText();
		
		//System.out.println(listValues);
		
		Select sc = new Select(findListOfValues);
		sc.selectByVisibleText("Electronics");
		driver.findElementByXPath("//input[@id='twotabsearchtextbox']").sendKeys("Redmi",Keys.ENTER);
		String price2Product = driver.findElementByXPath("(//span[@class='a-price-whole'])[2]").getText();
		System.out.println("2 Product Price: " +price2Product);
	

	}

}
