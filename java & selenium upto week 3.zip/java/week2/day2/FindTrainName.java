package week2.day2;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class FindTrainName {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		driver.get("https://www.erail.in/");
		
		driver.findElementByXPath("//input[@id='txtStationFrom']").clear();
		driver.findElementByXPath("//input[@id='txtStationFrom']").sendKeys("MAS",Keys.TAB);
		
		driver.findElementByXPath("//input[contains(@placeholder,'To')]").clear();
		driver.findElementByXPath("//input[contains(@placeholder,'To')]").sendKeys("SBC",Keys.TAB);
		
		WebElement checkBox = driver.findElementById("chkSelectDateOnly");
		if(checkBox.isSelected()) {
			checkBox.click();
		}
		
		WebElement tableEle = driver.findElementByXPath("//table[contains(@class,'DataTable TrainList TrainListHeader')]");
		
		List<WebElement> allRows = tableEle.findElements(By.tagName("tr"));
		int rowSize = allRows.size();
		System.out.println(rowSize);
		
		
		for(int i=0;i<rowSize;i++) {
			//WebElement rows = allRows.get(i);
			WebElement rows = allRows.get(i);
			List<WebElement> columns = rows.findElements(By.tagName("td"));
			WebElement colum = columns.get(1);
			System.out.println(colum.getText());
		}
		
		
	}

}
