package week2.day2;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class Draggable {

	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.get("https://jqueryui.com");
		driver.findElementByXPath("//a[text()='Droppable']").click();
		driver.switchTo().frame(0);
		WebElement eleDrag = driver.findElementById("draggable");
		WebElement eleDrop = driver.findElementById("droppable");
		
		Actions builder = new Actions(driver);
		
		builder.dragAndDrop(eleDrag, eleDrop).perform();
		
		
		

	}

}
