package week2.day2;

import org.openqa.selenium.chrome.ChromeDriver;

public class FindLeads {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.setProperty("webdriver.chrome.driver","./drivers/chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();
		driver.get("http://leaftaps.com/opentaps");
		driver.manage().window().maximize();
		driver.manage().window().maximize();
		driver.findElementById("username").sendKeys("demosalesmanager");
		driver.findElementById("password").sendKeys("crmsfa");
		driver.findElementByClassName("decorativeSubmit").click();
		driver.findElementByLinkText("CRM/SFA").click();
		
		driver.findElementByLinkText("Create Lead").click();
		driver.findElementByXPath("(//input[@name='companyName'])[2]").sendKeys("CTS");
		driver.findElementByXPath("//input[@id='createLeadForm_firstName']").sendKeys("Vediraj");
		driver.findElementByXPath("//input[@id='createLeadForm_lastName']").sendKeys("B");
		driver.findElementByXPath("//input[@id='createLeadForm_firstNameLocal']").sendKeys("Ronish");
		driver.findElementByXPath("//input[@id='createLeadForm_lastNameLocal']").sendKeys("V");
		
		
		
		
		
		
		
		

	

	}

}
