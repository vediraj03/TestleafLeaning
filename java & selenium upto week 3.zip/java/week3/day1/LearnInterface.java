package week3.day1;

public interface LearnInterface {
	void display();
	
	int num = 04;

}
