package week3.day1;

public class Audi extends Car{
public void sunRoof() {
	System.out.println("Sunroof for Audi");
}
}
