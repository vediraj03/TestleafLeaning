package week3.day1;

public class CitiBankAshokNagar extends CitiHO{

	public void maxTransLimit() {
		// TODO Auto-generated method stub
		
	}

	public int getCibilScore() {
		// TODO Auto-generated method stub
		return 0;
	}

	

}
