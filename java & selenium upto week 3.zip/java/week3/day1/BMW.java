package week3.day1;

public class BMW extends Car{
	public static void autoPark() {
		System.out.println("Auto Drive");
	}
	public void applyBrake() {
		System.out.println("ABS Apply brake ");
	}










}
