package week3.day1;

public class MyCar {
public static void main(String[] args) {
	BMW.autoPark();
}
}
