package week3.day1;

public abstract class Browser1 implements IBrowser {
	
	/*public void chromeBrowser() {
		System.out.println("Browser Title");
	}*/
	
	public void getTitle() {
		System.out.println("get the Browser attribute vale");
	}
	
	public String getVersion() {
		System.out.println("print the current URL");
		return null;
	}
	public void GetName() {
		System.out.println("Print the browser name");
	}
	
	public abstract String getCurrentUrl();

}
