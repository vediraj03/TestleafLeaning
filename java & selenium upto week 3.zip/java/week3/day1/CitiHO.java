package week3.day1;

public abstract class CitiHO implements RBI, CIBIL{

	public void setMinimumBalance() {
		System.out.println("5000");		
	}

	public void rateOfInterest() {
		System.out.println("13%");
	}

}
