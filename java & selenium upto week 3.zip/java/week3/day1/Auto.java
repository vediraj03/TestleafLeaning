package week3.day1;

public class Auto extends Vechicle{
public void handStarter() {
	System.out.println("Hand Starter");
}
}
