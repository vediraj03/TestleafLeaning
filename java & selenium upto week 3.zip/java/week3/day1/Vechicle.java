package week3.day1;

public class Vechicle {
	
	public void soundHorn() {
		System.out.println("Sound Horn");
	}
	public void applyBrake() {
		System.out.println("Apply brake");
	}

}
