package week3.day1;

public interface IBrowser {
	
	public void getTitle();
	
	public String getVersion();
	
	public String getName();

}
