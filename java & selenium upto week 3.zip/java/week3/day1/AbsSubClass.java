package week3.day1;

public class AbsSubClass extends LearnAbstract{

	@Override
	public void display() {
		System.out.println("display method ");		
	}




}
