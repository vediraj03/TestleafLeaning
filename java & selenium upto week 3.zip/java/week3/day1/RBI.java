package week3.day1;

public interface RBI {
	void setMinimumBalance();
	
	void rateOfInterest();
	
	void maxTransLimit();

}
