package week3.day1;

public class Bajaj extends Auto{
public void rainCover() {
	System.out.println("Rain Cover for Auto");
}
}
