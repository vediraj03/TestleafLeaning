package week3.day1;

public class Chrome extends Browser {

	public String getVersion() {
		return "77.0.1";
	}
	
	public String getName() {
		return "chrome";
	}
}
