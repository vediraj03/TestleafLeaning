package week3.day1;

public class ObjAbstract {
	public static void main(String[] args) {
//		LearnAbstract abs = new LearnAbstract();
		AbsSubClass abs = new AbsSubClass();
		abs.show();
	}

}
