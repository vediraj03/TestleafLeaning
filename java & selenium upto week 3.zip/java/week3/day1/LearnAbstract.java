package week3.day1;

public abstract class LearnAbstract {
	
	
	public abstract void display();
	private int i;
	public void show() {
		System.out.println("done");
	}

}






