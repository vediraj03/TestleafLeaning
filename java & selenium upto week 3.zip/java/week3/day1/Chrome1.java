package week3.day1;

import org.openqa.selenium.chrome.ChromeDriver;

public class Chrome1 extends Browser1 {
	
	public void chromeBrowser(String Url) {
		
		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
		ChromeDriver driver =new ChromeDriver();
		driver.get(Url);
	}
	public void chromeBrowser() {
		System.out.println("Browser Title");
	}
	public String getCurrentUrl() {
		System.out.println("print the current chrome URL");
		return "chromeName";
	}
	public String getName() {
		// TODO Auto-generated method stub
		System.out.println("get the chrome browser name");
		return "browserName";
	}

}
