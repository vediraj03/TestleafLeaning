package week3.day1;

public class MyBrowser {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Chrome1 chrome = new Chrome1();
		chrome.getCurrentUrl();
		chrome.getName();
		chrome.getTitle();
		chrome.getVersion();
		//Browser browser = new Browser();
		
	

	}

}
