package week3.day2;

import java.util.ArrayList;
import java.util.List;

public class ListReverseOrder {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		List<String> list = new ArrayList<String>();
		List<String> list1 =new ArrayList<String>();
		
		list.add("Vediraj");
		list.add("Ronish");
		list.add("Senthil");
		list.add("Ananya");
		list.add("Sakthi");
		
		for(int i=list.size()-1;i>=0;i--) {
			
			System.out.println(list.get(i));
			list1.add(list.get(i));
			
		}
		
		System.out.println("*****************");
		
		for (String rev : list1) {
			
			System.out.println(rev);
			
		}

	}

}
