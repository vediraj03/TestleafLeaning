package week3.day2;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

public class NumOfChar_Map {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String name = "AnanyaShree";
		char [] charName =name.toCharArray();
		
		Map<Character,Integer> map = new HashMap<Character, Integer>();
		int count =1;
		for (char c : charName) {
			if(map.containsKey(c)) {
				map.put(c,map.get(c)+1);
			}
			else {
				map.put(c, 1);
			
		}
		
		for(int i=0;i<name.length();i++) {
			if(map.containsKey(charName[i])) {
				map.put(charName[i], count+1);
			}
			else {
				map.put(charName[i], count);
			}
			
		}
		
		for (Entry<Character,Integer> eachchar:map.entrySet()) {
			System.out.println(eachchar.getKey()+"="+eachchar.getValue());
			
		}

	}

}
}