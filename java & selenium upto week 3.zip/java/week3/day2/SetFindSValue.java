package week3.day2;

import java.util.LinkedHashSet;
import java.util.Set;

public class SetFindSValue {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Set<String> set =new LinkedHashSet<String>();
		
		set.add("Vediraj");
		set.add("Ronish");
		set.add("Senthil");
		set.add("Ananya");
		set.add("Sakthi");
		
		for (String Svalu : set) {
			if(Svalu.startsWith("S")) {
				System.out.println(Svalu);
			}
			
		}
		

	}

}
