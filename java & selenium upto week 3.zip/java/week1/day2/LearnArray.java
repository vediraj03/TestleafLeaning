package week1.day2;

public class LearnArray {
	public static void main(String[] args) {
		// index == position
		String[] models = {"Benz", "Audi", "BMW","Jeep", "Nexa"};

		for(String eachModel : models) {
			System.out.println(eachModel);
		}
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		//		int length = models.length;
		/*for(int i=0; i <length;i++) {
			System.out.println(models[i]);
		}
		 */


	}
}
