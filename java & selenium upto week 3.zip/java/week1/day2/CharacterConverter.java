package week1.day2;

import java.util.Scanner;

public class CharacterConverter {

	public static void main(String[] args) {
	
		//initialize String
		//String string ="vedirajb";
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter the String:");
		String string = scanner.next();
		//initialize String Buffer
		StringBuffer stringBuffer = new StringBuffer();
		//convert string to char array
		char[] charArray = string.toCharArray();
		//iterate the character by index	
		
		for(int i=0;i<charArray.length;i++){
			//get the current character
			char c =charArray[i];
			//find the odd index iteration
			if(i%2!=0){
				//covert the odd index to upper case
				c=Character.toUpperCase(c);
			}
			//append character to string buffer
			stringBuffer.append(c);
		}
		
		System.out.println("Modified String: "+stringBuffer.toString());
		scanner.close();
	
	}

}
