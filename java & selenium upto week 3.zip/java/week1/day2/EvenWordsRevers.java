package week1.day2;

public class EvenWordsRevers {

	public static void main(String[] args) {
		
		String sentence = "i am a Softwat Tester in the Congizant";
		
		String []word =sentence.split(" ");
		
		for (int i=0;i<word.length;i++) {
			String reversString="";
			if(i%2!=0){
			for(int j=word[i].length()-1;j>=0;j--){
				reversString=reversString+word[i].charAt(j);
			}
			System.out.print(reversString+" ");
			}
			else{
				System.out.print(word[i]+" ");
		}
		}


	}

}
