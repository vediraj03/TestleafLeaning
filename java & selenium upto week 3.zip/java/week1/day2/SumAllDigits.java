package week1.day2;

import java.util.Scanner;

public class SumAllDigits {

	public static void main(String[] args) {
		
/*		//Scanner sc = new Scanner(System.in);
		
		//int enterValue = sc.nextInt();
		int enterValue =1546;
		int sum = 0, temp ;
		
		while(enterValue>0){
		
		temp =enterValue%10;
		sum=sum+temp;
		enterValue=enterValue/10;
		}
		System.out.println(sum);
		*/
		
		int enterValue =1546;
		int sum = 0, tmp ;
		for(int i=0;enterValue<0;i++){
			tmp =enterValue%10;
			sum=sum+tmp;
			enterValue=enterValue/10;
			i++;
		}
		
}
}