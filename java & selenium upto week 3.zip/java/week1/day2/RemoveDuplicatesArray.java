package week1.day2;

public class RemoveDuplicatesArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int [] marks ={10,20,30,10,40,30,20};
		
		int temp = 0;
		
		for (int i =0 ; i<marks.length;i++) {
			
			for(int j=i;j<marks.length;j++){
			
				if(i==j){
					
					temp =marks[j];
				}
				else{
					System.out.println(marks[j]);
				}
			}
			System.out.println(temp);
		}

	}

}
