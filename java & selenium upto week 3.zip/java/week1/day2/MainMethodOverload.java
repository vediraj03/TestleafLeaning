package week1.day2;

public class MainMethodOverload {

	
	public static void main(int a,int b) {
		System.out.println(a+b);
		
	}
	public static void main(String ar[]) {
		System.out.println("overload.main(10,5)");
		main(10,5);
		
	}

}
