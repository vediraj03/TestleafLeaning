package week1.day2;

public class overload {

	public static void main(int a) {
		System.out.println(a);
		
	}

}
