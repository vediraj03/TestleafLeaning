package week1.day1;

public class LearnControlStatement {

	public static void main(String[] args) {
		int age=17;
		
		if(age<=17) {
			System.out.println("child");
		}else {
			System.out.println("adult");
		}

	}

}
