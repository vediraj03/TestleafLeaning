package week1.day1;

public class LearnPrimitive {
	
	public static void main(String[] args) {
		byte age=100;
		float interest=10.25f;
		
		
		System.out.println(age);
		System.out.println(interest);
	}
}
