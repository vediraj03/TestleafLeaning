package week1.day1;

public class Car {
	// public, private, protected, 
	//	package or default
	String brand = "Benz";
	int region = 22123144;
	double airVolume = 36.4321;
	char firstLetter = 'b';
	boolean hasSunRoof = true;
	// method signature
	public void driveCar() {
		// body of the method - logic part
	}
	public String getColor() {
		return "blue";
	}
	public boolean isPunctured() {
		return false;
	}
	
	
	
	
	
	
	

}
