package week1.day1;

public class LearnOperators {

	public static void main(String[] args) {
		int num1=10;
	//	int num2=15;
	//	System.out.println("Add :"+(num1%num2));
		//System.out.println((num1>10)&&(num2>10));
		
	//	System.out.println(!(num1>10));
		//num1++;//num1=num1+1 post increment
		//++num1;
				
		System.out.println(++num1);//
		System.out.println(num1);
		

	}

}
